package org.mai.dep1010.quantity;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Asus on 9/24/2018.
 */
public class QuantityTest {
    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void add() throws Exception {
    }

    @Test
    public void subtract() throws Exception {
    }

    @Test
    public void multiply() throws Exception {
    }

    @Test
    public void devide() throws Exception {
    }

}