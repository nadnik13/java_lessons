package org.mai.dep1010.quantity;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.math.BigDecimal;

public class Main {
    public static void main(String[] args) {
        UnitOfMeasure kg = UnitOfMeasure.KG;
        UnitOfMeasure g = UnitOfMeasure.G;
        UnitOfMeasure t = UnitOfMeasure.T;

        BigDecimal v1 = new BigDecimal("5.0");
        BigDecimal v2 = new BigDecimal("6.0");
        Quantity b1 = new Quantity(v1,kg);
        Quantity b2 = new Quantity(v2,g);

        b1 = b1.divide(v2);
        System.out.println(b1.toString());
        b1 = b1.multiply(v1);
        System.out.println(b1.toString());
        b1 = b2.add(b1);
    }
}
