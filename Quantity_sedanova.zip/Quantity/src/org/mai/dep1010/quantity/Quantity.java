package org.mai.dep1010.quantity;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Quantity {
    private BigDecimal value;
    private UnitOfMeasure measure;

    public Quantity(BigDecimal value, UnitOfMeasure measure) {
        this.value = value;
        this.measure = measure;
    }

    public BigDecimal getValue() {
        return value;
    }

    public UnitOfMeasure getMeasure() {
        return measure;
    }

    public Quantity add(Quantity other) {
        if (other.getMeasure().getCoeff() != this.getMeasure().getCoeff()) {
            System.out.println("Величины имеют разные единицы измерения, для совершения операции нужно сделать преобразование.");
            return this;
        }
        else{
            return new Quantity(this.value.add(other.value), this.getMeasure());
        }
    }

    public Quantity subtract(Quantity other) {
        if (other.getMeasure().getCoeff() != this.getMeasure().getCoeff()) {
            System.out.println("Величины имеют разные единицы измерения, для совершения операции нужно сделать преобразование.");
            return this;
        } else
            return new Quantity(this.value.subtract(other.value), this.getMeasure());

    }

    public Quantity multiply(BigDecimal ratio) {
        BigDecimal a = new BigDecimal(this.getValue().toString()).setScale( 2, RoundingMode.HALF_UP);
        BigDecimal b = new BigDecimal(ratio.toString()).setScale(2, RoundingMode.HALF_UP);
        return new Quantity(a.multiply(b), this.getMeasure());
    }

    public Quantity divide(BigDecimal ratio) {
        BigDecimal a = new BigDecimal(this.value.toString()).setScale( 2, RoundingMode.HALF_UP);
        BigDecimal b = new BigDecimal(ratio.toString()).setScale(2, RoundingMode.HALF_UP);
        return new Quantity(a.divide(b,RoundingMode.HALF_UP), this.getMeasure());
    }

    public String toString() {
        return value + " " + measure;
    }

}
